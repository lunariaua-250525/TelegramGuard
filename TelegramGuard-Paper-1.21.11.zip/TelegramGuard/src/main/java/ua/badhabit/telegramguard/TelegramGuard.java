package ua.badhabit.telegramguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public final class TelegramGuard extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private final Map<UUID, PendingLogin> pending = new ConcurrentHashMap<>();
    private final Map<UUID, LinkData> links = new ConcurrentHashMap<>();
    private final Map<String, UUID> linkCodes = new ConcurrentHashMap<>();
    private final Map<UUID, Location> freezeLocations = new ConcurrentHashMap<>();

    private Properties data = new Properties();
    private Path dataFile;
    private ScheduledExecutorService telegramExecutor;
    private BukkitTask titleTask;

    private volatile long updateOffset = 0;
    private volatile boolean running = false;

    private HttpClient http;
    private String botToken;
    private long adminChatId;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        reloadTelegramConfig();

        Bukkit.getPluginManager().registerEvents(this, this);

        PluginCommand cmd = getCommand("tg");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }

        titleTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (UUID uuid : pending.keySet()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) showTitle(p);
            }
        }, 1L, Math.max(10L, getConfig().getLong("screen.repeat-every-ticks", 20)));

        if (isTelegramConfigured()) {
            startTelegramPolling();
            getLogger().info("TelegramGuard enabled. Telegram polling started.");
        } else {
            getLogger().warning("TelegramGuard: configure telegram.bot-token and telegram.admin-chat-id.");
        }
    }

    @Override
    public void onDisable() {
        running = false;
        if (telegramExecutor != null) telegramExecutor.shutdownNow();
        if (titleTask != null) titleTask.cancel();
        saveData();
    }

    private void reloadTelegramConfig() {
        botToken = getConfig().getString("telegram.bot-token", "");
        adminChatId = getConfig().getLong("telegram.admin-chat-id", 0);
        http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    private boolean isTelegramConfigured() {
        return botToken != null && !botToken.isBlank()
                && !botToken.equals("PUT_BOT_TOKEN_HERE")
                && adminChatId != 0;
    }

    /* =========================
       DATA
       ========================= */

    private void loadData() {
        dataFile = getDataFolder().toPath().resolve("players.properties");
        try {
            if (!getDataFolder().exists()) getDataFolder().mkdirs();
            if (Files.exists(dataFile)) {
                try (InputStream in = Files.newInputStream(dataFile)) {
                    data.load(in);
                }
            }
            for (String key : data.stringPropertyNames()) {
                if (!key.startsWith("link.")) continue;
                try {
                    UUID uuid = UUID.fromString(key.substring(5));
                    String[] parts = data.getProperty(key, "").split("\\|", -1);
                    if (parts.length >= 1) {
                        long telegramId = Long.parseLong(parts[0]);
                        String username = parts.length > 1 ? parts[1] : "";
                        links.put(uuid, new LinkData(telegramId, username));
                    }
                } catch (Exception ignored) {}
            }
        } catch (IOException e) {
            getLogger().severe("Cannot load players.properties: " + e.getMessage());
        }
    }

    private synchronized void saveData() {
        try {
            if (!getDataFolder().exists()) getDataFolder().mkdirs();
            Properties out = new Properties();
            for (Map.Entry<UUID, LinkData> e : links.entrySet()) {
                out.setProperty("link." + e.getKey(),
                        e.getValue().telegramId + "|" + safe(e.getValue().username));
            }
            try (OutputStream os = Files.newOutputStream(dataFile)) {
                out.store(os, "TelegramGuard player links");
            }
        } catch (IOException e) {
            getLogger().severe("Cannot save players.properties: " + e.getMessage());
        }
    }

    private String safe(String s) {
        return s == null ? "" : s.replace("|", "");
    }

    /* =========================
       JOIN / AUTH INTEGRATION
       ========================= */

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("security.verify-every-join", true)) return;
        if (getConfig().getString("auth.mode", "COMMAND").equalsIgnoreCase("JOIN")) {
            Bukkit.getScheduler().runTaskLater(this, () -> beginVerification(event.getPlayer()), 2L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player p = event.getPlayer();
        if (!pending.containsKey(p.getUniqueId())) {
            String mode = getConfig().getString("auth.mode", "COMMAND");
            if (mode.equalsIgnoreCase("COMMAND")) {
                String raw = event.getMessage();
                String command = raw.startsWith("/") ? raw.substring(1) : raw;
                String label = command.split("\\s+")[0].toLowerCase(Locale.ROOT);
                label = label.contains(":") ? label.substring(label.lastIndexOf(':') + 1) : label;

                List<String> loginCommands = getConfig().getStringList("auth.login-commands");
                if (loginCommands.stream().map(x -> x.toLowerCase(Locale.ROOT))
                        .anyMatch(x -> x.equals(label))) {
                    long delay = Math.max(1L, getConfig().getLong("auth.auth-check-delay-ticks", 2));
                    Bukkit.getScheduler().runTaskLater(this, () -> {
                        if (p.isOnline()) beginVerification(p);
                    }, delay);
                }
            }
        } else {
            event.setCancelled(true);
            p.sendMessage(color(getConfig().getString("messages.frozen-chat")));
        }
    }

    private void beginVerification(Player p) {
        if (!p.isOnline()) return;
        if (p.hasPermission("telegramguard.bypass")) return;
        if (pending.containsKey(p.getUniqueId())) return;

        if (!isTelegramConfigured()) {
            p.sendMessage(color(getConfig().getString("messages.bot-not-configured")));
            return;
        }

        LinkData link = links.get(p.getUniqueId());
        if (link == null) {
            p.sendMessage(color(getConfig().getString("messages.not-linked")));
            showTitle(p);
            return;
        }

        String ip = getIp(p);
        PendingLogin login = new PendingLogin(
                p.getUniqueId(), p.getName(), ip, Instant.now(),
                UUID.randomUUID().toString().replace("-", "")
        );

        pending.put(p.getUniqueId(), login);
        freezeLocations.put(p.getUniqueId(), p.getLocation().clone());
        p.setVelocity(new Vector(0, 0, 0));
        showTitle(p);
        p.sendMessage(color(getConfig().getString("messages.frozen-chat")));

        sendLoginRequest(p, link, login);
        scheduleTimeout(login);
    }

    private void scheduleTimeout(PendingLogin login) {
        long seconds = Math.max(5, getConfig().getLong("security.verification-timeout-seconds", 60));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            PendingLogin current = pending.remove(login.uuid);
            if (current == null) return;

            freezeLocations.remove(login.uuid);
            Player p = Bukkit.getPlayer(login.uuid);
            if (p != null && p.isOnline()) {
                p.sendMessage(color(getConfig().getString("messages.timeout")));
                if (getConfig().getBoolean("security.kick-on-timeout", true)) {
                    p.kickPlayer(color(getConfig().getString("messages.timeout")));
                }
            }
            sendAdminText("⏱ Підтвердження входу закінчилось\n👤 " + login.name);
        }, seconds * 20L);
    }

    private void showTitle(Player p) {
        String title = color(getConfig().getString("screen.title"));
        String subtitle = color(getConfig().getString("screen.subtitle"));
        p.sendTitle(title, subtitle,
                getConfig().getInt("screen.fade-in-ticks", 0),
                getConfig().getInt("screen.stay-ticks", 40),
                getConfig().getInt("screen.fade-out-ticks", 0));
    }

    /* =========================
       FREEZE
       ========================= */

    private boolean frozen(Player p) {
        return pending.containsKey(p.getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!frozen(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to != null && (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ())) {
            e.setTo(from);
            e.getPlayer().setVelocity(new Vector(0, 0, 0));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHeld(PlayerItemHeldEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommandWhileFrozen(PlayerCommandPreprocessEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onQuit(PlayerQuitEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        pending.remove(uuid);
        freezeLocations.remove(uuid);
    }

    /* =========================
       TELEGRAM
       ========================= */

    private void startTelegramPolling() {
        if (running) return;
        running = true;
        telegramExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "TelegramGuard-Poll");
            t.setDaemon(true);
            return t;
        });

        telegramExecutor.scheduleWithFixedDelay(() -> {
            try {
                pollUpdates();
            } catch (Exception e) {
                getLogger().warning("Telegram polling error: " + e.getMessage());
            }
        }, 0, Math.max(1000L, getConfig().getLong("telegram.poll-delay-ms", 1000)), TimeUnit.MILLISECONDS);
    }

    private void pollUpdates() throws Exception {
        String url = api("getUpdates") + "?timeout=10&offset=" + updateOffset;
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(20)).GET().build();

        String body = http.send(req, HttpResponse.BodyHandlers.ofString()).body();

        Matcher ok = Pattern.compile("\"ok\"\\s*:\\s*true").matcher(body);
        if (!ok.find()) return;

        Matcher upd = Pattern.compile("\"update_id\"\\s*:\\s*(\\d+)").matcher(body);
        while (upd.find()) {
            long id = Long.parseLong(upd.group(1));
            updateOffset = id + 1;

            int start = upd.start();
            int next = body.indexOf("\"update_id\"", start + 1);
            String one = next > start ? body.substring(start, next) : body.substring(start);

            handleTelegramUpdate(one);
        }
    }

    private void handleTelegramUpdate(String json) {
        Matcher msgText = Pattern.compile("\"message\"\\s*:\\s*\\{.*?\"text\"\\s*:\\s*\"([^\"]*)\"", Pattern.DOTALL).matcher(json);
        if (msgText.find()) {
            long chatId = extractLong(json, "\"chat\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*(-?\\d+)");
            long fromId = extractLong(json, "\"from\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*(\\d+)");
            String text = unescape(msgText.group(1)).trim();
            if (chatId != 0) handleText(chatId, fromId, text);
        }

        Matcher cb = Pattern.compile("\"callback_query\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*\"([^\"]+)\".*?\"from\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*(\\d+).*?\"data\"\\s*:\\s*\"([^\"]+)\"", Pattern.DOTALL).matcher(json);
        if (cb.find()) {
            String callbackId = cb.group(1);
            long fromId = Long.parseLong(cb.group(2));
            String callbackData = unescape(cb.group(3));
            if (fromId != adminChatId) {
                answerCallback(callbackId, "⛔ Недозволено", true);
                return;
            }
            answerCallback(callbackId, "Оброблено", false);
            handleCallback(callbackData);
        }
    }

    private void handleText(long chatId, long fromId, String text) {
        if (text.equals("/start")) {
            sendMessage(chatId,
                    "🔐 TelegramGuard\n\n" +
                    "Прив'яжіть Minecraft-акаунт через код:\n" +
                    "/link КОД\n\n" +
                    "Після прив'язки кожен вхід на сервер потрібно буде підтвердити.");
            return;
        }

        if (text.startsWith("/link ")) {
            if (chatId != fromId) return;
            String code = text.substring(6).trim();
            UUID uuid = linkCodes.remove(code);
            if (uuid == null) {
                sendMessage(chatId, "❌ Код недійсний або вже використаний.");
                return;
            }

            links.put(uuid, new LinkData(chatId, ""));
            saveData();

            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                p.sendMessage(color("§aTelegram успішно прив'язано."));
            }
            sendMessage(chatId, "✅ Minecraft-акаунт успішно прив'язано.");
        }
    }

    private void handleCallback(String data) {
        if (!data.startsWith("tg:")) return;
        String[] parts = data.split(":", 3);
        if (parts.length < 3) return;

        String action = parts[1];
        UUID uuid;
        try {
            uuid = UUID.fromString(parts[2]);
        } catch (Exception e) {
            return;
        }

        PendingLogin login = pending.get(uuid);
        if (login == null) {
            sendAdminText("ℹ️ Цей запит уже не активний.");
            return;
        }

        if (action.equals("approve")) approve(uuid);
        else if (action.equals("reject")) reject(uuid);
    }

    private void approve(UUID uuid) {
        PendingLogin login = pending.remove(uuid);
        freezeLocations.remove(uuid);
        if (login == null) return;

        Player p = Bukkit.getPlayer(uuid);
        if (p != null && p.isOnline()) {
            p.sendMessage(color(getConfig().getString("messages.approved")));
            p.resetTitle();
        }
        sendAdminText("✅ ВХІД ПІДТВЕРДЖЕНО\n👤 " + login.name + "\n🌐 IP: " + login.ip);
    }

    private void reject(UUID uuid) {
        PendingLogin login = pending.remove(uuid);
        freezeLocations.remove(uuid);
        if (login == null) return;

        Player p = Bukkit.getPlayer(uuid);
        if (p != null && p.isOnline()) {
            p.sendMessage(color(getConfig().getString("messages.rejected")));
            if (getConfig().getBoolean("security.kick-on-reject", true)) {
                p.kickPlayer(color("§cВхід відхилено.\n§7Якщо це були не ви — змініть пароль AUTH."));
            }
        }
        sendAdminText("❌ ВХІД ВІДХИЛЕНО\n👤 " + login.name + "\n🌐 IP: " + login.ip);
    }

    private void sendLoginRequest(Player p, LinkData link, PendingLogin login) {
        CompletableFuture.runAsync(() -> {
            String geo = "";
            if (getConfig().getBoolean("security.geoip.enabled", true)) {
                geo = lookupGeo(login.ip);
            }

            StringBuilder text = new StringBuilder();
            text.append("🔐 НОВИЙ ВХІД НА СЕРВЕР\n\n");
            text.append("👤 Гравець: ").append(login.name).append("\n");
            text.append("🆔 UUID: ").append(login.uuid).append("\n");
            text.append("🌐 IP: ").append(login.ip).append("\n");
            if (!geo.isBlank()) text.append("📍 Місце: ").append(geo).append("\n");
            text.append("🕐 Час: ").append(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")
                    .withZone(ZoneId.systemDefault()).format(login.time)).append("\n\n");
            text.append("❓ Це ви входите на сервер?");

            String keyboard = "{\"inline_keyboard\":[[" +
                    "{\"text\":\"✅ ЦЕ Я\",\"callback_data\":\"tg:approve:" + login.uuid + "\"}," +
                    "{\"text\":\"❌ ЦЕ НЕ Я\",\"callback_data\":\"tg:reject:" + login.uuid + "\"}" +
                    "]]}";

            sendMessageWithKeyboard(adminChatId, text.toString(), keyboard);
        });
    }

    private String lookupGeo(String ip) {
        try {
            String endpoint = String.format(getConfig().getString("security.geoip.endpoint"), URLEncoder.encode(ip, StandardCharsets.UTF_8));
            HttpRequest req = HttpRequest.newBuilder(URI.create(endpoint))
                    .timeout(Duration.ofSeconds(5)).GET().build();
            String json = http.send(req, HttpResponse.BodyHandlers.ofString()).body();

            String country = extractString(json, "\"country\"\\s*:\\s*\"([^\"]*)\"");
            String city = extractString(json, "\"city\"\\s*:\\s*\"([^\"]*)\"");
            if (!country.isBlank() && !city.isBlank()) return country + ", " + city;
            return country;
        } catch (Exception e) {
            return "";
        }
    }

    private void sendAdminText(String text) {
        if (isTelegramConfigured()) sendMessage(adminChatId, text);
    }

    private void sendMessage(long chatId, String text) {
        sendMessageWithKeyboard(chatId, text, null);
    }

    private void sendMessageWithKeyboard(long chatId, String text, String keyboardJson) {
        CompletableFuture.runAsync(() -> {
            try {
                String body = "chat_id=" + URLEncoder.encode(Long.toString(chatId), StandardCharsets.UTF_8)
                        + "&text=" + URLEncoder.encode(text, StandardCharsets.UTF_8);
                if (keyboardJson != null) {
                    body += "&reply_markup=" + URLEncoder.encode(keyboardJson, StandardCharsets.UTF_8);
                }

                HttpRequest req = HttpRequest.newBuilder(URI.create(api("sendMessage")))
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .timeout(Duration.ofSeconds(10))
                        .POST(HttpRequest.BodyPublishers.ofString(body))
                        .build();
                http.send(req, HttpResponse.BodyHandlers.ofString());
            } catch (Exception e) {
                getLogger().warning("Cannot send Telegram message: " + e.getMessage());
            }
        });
    }

    private void answerCallback(String callbackId, String text, boolean alert) {
        CompletableFuture.runAsync(() -> {
            try {
                String body = "callback_query_id=" + URLEncoder.encode(callbackId, StandardCharsets.UTF_8)
                        + "&text=" + URLEncoder.encode(text, StandardCharsets.UTF_8)
                        + "&show_alert=" + alert;
                HttpRequest req = HttpRequest.newBuilder(URI.create(api("answerCallbackQuery")))
                        .header("Content-Type", "application/x-www-form-urlencoded")
                        .POST(HttpRequest.BodyPublishers.ofString(body))
                        .build();
                http.send(req, HttpResponse.BodyHandlers.ofString());
            } catch (Exception ignored) {}
        });
    }

    private String api(String method) {
        return "https://api.telegram.org/bot" + botToken + "/" + method;
    }

    /* =========================
       COMMANDS
       ========================= */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                reloadTelegramConfig();
                sender.sendMessage("TelegramGuard reloaded.");
                return true;
            }
            sender.sendMessage("Use /tg reload from console.");
            return true;
        }

        if (args.length == 0) {
            p.sendMessage("§6§lTelegramGuard §7- /tg link, /tg unlink, /tg status");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "link" -> {
                if (links.containsKey(p.getUniqueId())) {
                    p.sendMessage(color(getConfig().getString("messages.already-linked")));
                    return true;
                }
                String code = generateCode();
                linkCodes.put(code, p.getUniqueId());
                long expire = getConfig().getLong("link.code-expire-minutes", 10);
                Bukkit.getScheduler().runTaskLater(this, () -> linkCodes.remove(code), expire * 60L * 20L);
                p.sendMessage(color(String.format(getConfig().getString("messages.link-code"), code, code)));
            }
            case "unlink" -> {
                links.remove(p.getUniqueId());
                saveData();
                p.sendMessage(color(getConfig().getString("messages.unlinked")));
            }
            case "status" -> {
                boolean linked = links.containsKey(p.getUniqueId());
                p.sendMessage(color(getConfig().getString(linked ? "messages.status-linked" : "messages.status-unlinked")));
            }
            case "reload" -> {
                if (!p.hasPermission("telegramguard.admin")) {
                    p.sendMessage(color(getConfig().getString("messages.no-permission")));
                    return true;
                }
                reloadConfig();
                reloadTelegramConfig();
                p.sendMessage("§aTelegramGuard перезавантажено.");
            }
            default -> p.sendMessage("§7/tg link §f| §7/tg unlink §f| §7/tg status §f| §7/tg reload");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Arrays.asList("link", "unlink", "status", "reload");
        return Collections.emptyList();
    }

    private String generateCode() {
        Random r = new Random();
        String code;
        do {
            code = String.format("%0" + getConfig().getInt("link.code-length", 6) + "d",
                    r.nextInt((int)Math.pow(10, getConfig().getInt("link.code-length", 6))));
        } while (linkCodes.containsKey(code));
        return code;
    }

    /* =========================
       HELPERS
       ========================= */

    private String getIp(Player p) {
        if (p.getAddress() == null || p.getAddress().getAddress() == null) return "unknown";
        return p.getAddress().getAddress().getHostAddress();
    }

    private static String color(String s) {
        return s == null ? "" : ChatColor.translateAlternateColorCodes('&', s);
    }

    private static long extractLong(String text, String regex) {
        try {
            Matcher m = Pattern.compile(regex, Pattern.DOTALL).matcher(text);
            return m.find() ? Long.parseLong(m.group(1)) : 0;
        } catch (Exception e) { return 0; }
    }

    private static String extractString(String text, String regex) {
        try {
            Matcher m = Pattern.compile(regex, Pattern.DOTALL).matcher(text);
            return m.find() ? unescape(m.group(1)) : "";
        } catch (Exception e) { return ""; }
    }

    private static String unescape(String s) {
        return s.replace("\\\"", "\"").replace("\\\\", "\\").replace("\\n", "\n");
    }

    record LinkData(long telegramId, String username) {}
    record PendingLogin(UUID uuid, String name, String ip, Instant time, String requestId) {}
}
